package test.com.flyzipline.main;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.flyzipline.main.Flight;
import com.flyzipline.main.Order;
import com.flyzipline.main.Runner;
import com.flyzipline.main.Scheduler;

public class TestZips {

    private Runner runner;

    @Test
    public void testOrders1() {
        // Change absolute paths based on directory structure
        runner = new Runner(
            "/Users/cameronjavaheri/Downloads/traveling_results/inputs/hospitals.csv",
            "/Users/cameronjavaheri/Downloads/traveling_results/inputs/testOrders.csv"
        );
        Scheduler scheduler = runner.getScheduler();
        List<List<Flight>> allFlights = runner.run(25682);
        List<Flight> flights = allFlights.get(0);

        for (Flight flight: flights) {
            List<Order> orders = flight.getOrders();
            Assert.assertTrue(orders.size() <= scheduler.getMaxPackagesPerZip());

            double x1 = 0;
            double y1 = 0;
            double dist = 0.0;

            for (int i = 0; i < orders.size(); i++) {
                Order order = orders.get(i);
                double x2 = order.hospital().eastM();
                double y2 = order.hospital().northM();
                dist += Scheduler.calculateDistanceBetweenPoints(x1, y1, x2, y2);
                x1 = x2;
                y1 = y2;

                if (i+1 < orders.size()) {
                    Order nextOrder = orders.get(i+1);
                    Assert.assertTrue(order.priority().compareTo(nextOrder.priority()) <= 0);
                }
            }

            dist += Scheduler.calculateDistanceBetweenPoints(x1, y1, 0.0, 0.0);

            Assert.assertTrue(dist <= scheduler.getZipMaxCumulativeRangeM());

        }
    }

    // TODO: Add more tests regarding arrival times
}
