package com.flyzipline.main;

public enum Priority {
    Emergency, Resupply
}
