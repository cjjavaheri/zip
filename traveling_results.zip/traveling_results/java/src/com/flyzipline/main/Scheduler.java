package com.flyzipline.main;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;


public class Scheduler {
    private final HospitalDirectory hospitalDirectory;
    private final int numZips;
    private final int maxPackagesPerZip;
    private final int zipSpeedMps;
    private final int zipMaxCumulativeRangeM;

    private int zipsAvailable;

    private final List<Order> unfulfilledOrders;

    private final Queue<Double> arrivalTimes;

    public Scheduler(
            HospitalDirectory hospitalDirectory,
            int numZips,
            int maxPackagesPerZip,
            int zipSpeedMps,
            int zipMaxCumulativeRangeM
    ) {
        this.hospitalDirectory = hospitalDirectory;
        this.numZips = numZips;
        this.maxPackagesPerZip = maxPackagesPerZip;
        this.zipSpeedMps = zipSpeedMps;
        this.zipMaxCumulativeRangeM = zipMaxCumulativeRangeM;

        // Track which orders haven't been launched yet
        this.unfulfilledOrders = new ArrayList<>();
        // Track when a drone arrives back at the nest
        this.arrivalTimes = new LinkedList<Double>();
        this.zipsAvailable = numZips;
    }

    public int getMaxPackagesPerZip() {
        return maxPackagesPerZip;
    }

    public int getZipMaxCumulativeRangeM() {
        return zipMaxCumulativeRangeM;
    }

    /**
     * Add a new order to our queue
     * <p>
     * Note: Called every time a new order arrives
     *
     * @param order the order just placed
     */
    public void queueOrder(Order order) {
        this.unfulfilledOrders.add(order);
    }

    /**
     * Determines which flights should be launched right now. Each flight has an ordered list of Orders to serve.
     * <p>
     * Note: Will be called periodically (approximately once a minute).
     *
     * @param currentTime Seconds since midnight.
     * @return Flight objects that launch at this time.
     */
    public List<Flight> launchFlights(int currentTime) {
        List<Flight> flights = new ArrayList<>();

        while (!arrivalTimes.isEmpty() && currentTime >= arrivalTimes.peek()) {
            arrivalTimes.remove();
            zipsAvailable++;
        }

        for (int i = 0; i < zipsAvailable; i++) {
            flights.add(new Flight(currentTime, new ArrayList<>()));
        }

        fillZipsWithPackages(flights, currentTime, Priority.Emergency);
        fillZipsWithPackages(flights, currentTime, Priority.Resupply);

        for (int i = 0; i < flights.size(); i++) {
            if (flights.get(i).getOrders().isEmpty()) {
                flights.remove(i);
                i--;
            }
        }
        zipsAvailable = zipsAvailable - flights.size();
        return flights;
    }

    protected void fillZipsWithPackages(List<Flight> flights, int currentTime, Priority urgency) {
        boolean allFlightsFull = false;
        int j = 0;
        while (!allFlightsFull && j < unfulfilledOrders.size()) {
            Order newOrder = unfulfilledOrders.get(j);
            Priority priority = newOrder.priority();

            if (priority.compareTo(urgency) == 0) {

                allFlightsFull = true;
                boolean packageFilled = false;
    
                for (int i = 0; i < zipsAvailable && !packageFilled; i++) {
                    Flight flight = flights.get(i);
                    List<Order> orders = flight.getOrders();
                    orders.add(newOrder);
                    double roundTripDist = calculateRoundTripDistance(orders);
                    double flightTime = roundTripDist / Double.valueOf(zipSpeedMps);
                    double arrivalTime = currentTime + flightTime;
    
                    if (roundTripDist <= zipMaxCumulativeRangeM && orders.size() <= maxPackagesPerZip) {
                        packageFilled = true;
                        allFlightsFull = false;
                        unfulfilledOrders.remove(newOrder);
                        arrivalTimes.add(arrivalTime);
                    }
                    else {
                        orders.remove(newOrder);
                    }
                }
            }
            else {
                j++;
            }
        }
    }

    protected double calculateRoundTripDistance(List<Order> orders) {
        double dist = 0.0;
        double x1 = 0;
        double y1 = 0;
        double x2;
        double y2;

        for (Order order: orders) {
            x2 = order.hospital().eastM();
            y2 = order.hospital().northM();
            dist += calculateDistanceBetweenPoints(x1, y1, x2, y2);
            x1 = x2;
            y1 = y2;
        }
        dist += calculateDistanceBetweenPoints(x1, y1, 0, 0);
        return dist;
    }

    public static double calculateDistanceBetweenPoints(double x1, double y1, double x2, double y2) {
        return Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
    }

    public List<Order> getUnfulfilledOrders() {
        return unfulfilledOrders;
    }

    public Queue<Double> getArrivalTimes() {
        return arrivalTimes;
    }
}
