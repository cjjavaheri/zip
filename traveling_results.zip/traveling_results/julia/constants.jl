# Number of seconds per day
const SEC_PER_DAY = 24 * 60 * 60
